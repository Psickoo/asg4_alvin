class Menu {
  String title;
  int amount;

  Menu({required this.title, required this.amount});
}
